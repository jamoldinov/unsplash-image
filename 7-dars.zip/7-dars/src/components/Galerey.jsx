import { Link } from "react-router-dom"
import Image from "../pages/Image"

function Galerey({ data: { results } }) {
  console.log(results)
  return <div className="galerey">
    <ul>
      {results.map((image) => {
        return (
          <li key={image.id}>
            <Link to={image.user.social.portfolio_url}>
              <img className="m-auto" src={image.urls.regular} alt="" />
              <div>
                <h1><i>Username:</i> {image.user.first_name
}</h1>
<span><i>Likes:</i> {image.likes}</span>
              </div>
            </Link>
          </li>
        )
      })}
      {/* <Image results={results} /> */}
    </ul>
  </div>
}

export default Galerey