import React from 'react'
import { Link } from 'react-router-dom'

function Image() {
  return (
    <div className='mt-24'>
        <Link className='btn btn-outline btn-neutral' to="/">Go Home</Link>
    </div>
  )
}

export default Image