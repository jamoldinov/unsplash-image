import React from 'react'

function About() {
  return (
    <div>
        <h2 className='text-center font-bold text-xl mt-10 mb-3'>About</h2>
        <p className='text-center font-medium'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cumque atque consequuntur dignissimos molestias, ab magnam quam. Facilis culpa in et dolore alias voluptatem veritatis harum inventore sed, temporibus a! Eaque delectus, culpa placeat at recusandae asperiores? Hic, eaque veniam cupiditate officiis quod ipsum fugit doloremque sed harum ea temporibus, aperiam aspernatur possimus rem facere sapiente! Commodi, modi laborum quam corrupti, iusto nam consectetur eligendi libero provident itaque corporis ad quisquam alias officia nobis, repudiandae dolore reprehenderit similique iste. Labore, fuga autem? Velit dolores nemo unde, consequuntur ratione ipsum, explicabo voluptas, fuga officiis reiciendis architecto soluta? Sed distinctio mollitia quam tenetur?</p>
    </div>
  )
}

export default About